# Test Cases

Record the actual result and Pass/Fail during your group test and demonstration.

| Test | Steps | Expected result |
|---|---|---|
| Valid customer | Register a customer with valid name, email, and city | Customer is saved and receives an ID |
| Duplicate email | Register another customer using the same email | Duplicate is rejected; no duplicate row is saved |
| Invalid email | Enter an invalid email | Program asks again |
| Place order | Select a customer and add at least one product | Order and its items are saved together |
| Invalid customer ID | Place an order using a nonexistent customer ID | Program rejects the ID |
| View/search | View all orders and search for an existing/nonexistent order | Matching rows or a clear empty result |
| Update shipping | Move Pending → Processing → Shipped → Delivered | Status and tracking history are updated |
| Invalid status transition | Attempt to skip a required shipping step | Transition is not offered |
| Update payment | Change payment status | Payment status is saved |
| Update item quantity | Change a line-item quantity while Pending/Processing | Quantity and computed order total change |
| Delete | Delete an existing order and confirm | Order and dependent items/history are deleted |
| Cancel delete | Choose No at confirmation | Record remains |
| Persistence | Close and reopen the program | Saved records remain |
| Analytics | Open the shipping/payment board | Counts and totals reflect database rows |
| Charts | Choose menu option 11 | Two PNG chart files are generated in `charts/` |
| Foreign keys | Inspect database relationships / attempt orphan insert | Invalid references are rejected |
| Fresh setup | Run `python main.py` from the project folder | Program starts using the included database |
