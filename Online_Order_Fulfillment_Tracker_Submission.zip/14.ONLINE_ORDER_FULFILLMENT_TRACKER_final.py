"""Online Order Fulfillment Tracker.

DSA 214 - Final Laboratory Activity - Scenario 14.
Command-line app: track customer orders, order items, shipping statuses,
payment totals AND where each parcel is on a delivery map, using
Python + SQLite (standard library only).
"""

import html
import os
import random
import re
import sqlite3
import sys
import time
import urllib.parse
import webbrowser
from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path

EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")

@dataclass
class Customer:
    """A registered customer of the order fulfillment system."""
    name: str
    email: str
    city: str

# Business rule: which shipping status may follow which.
ALLOWED_TRANSITIONS = {
    "Pending": ["Processing", "Cancelled"],
    "Processing": ["Shipped", "Cancelled"],
    "Shipped": ["Delivered"],
    "Delivered": [],
    "Cancelled": [],
}
EDITABLE_STATUSES = ("Pending", "Processing")  # items may only change before shipping

try:  
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError):
    pass

UNICODE_OK = ("NO_EMOJI" not in os.environ
              and (getattr(sys.stdout, "encoding", "") or "").lower().replace("-", "") == "utf8")
_USE_COLOR = sys.stdout.isatty() and "NO_COLOR" not in os.environ
if _USE_COLOR and os.name == "nt":
    os.system("") 

STATUS_STYLES = {
    "Pending": "33", "Processing": "36", "Shipped": "34", "Delivered": "32",
    "Cancelled": "31", "Unpaid": "33", "Paid": "32", "Refunded": "35",
}

def style(text, code):
    """Wrap ``text`` in an ANSI color code (plain text if colors are off)."""
    return f"\033[{code}m{text}\033[0m" if _USE_COLOR else text

def icon(emoji):
    """Return ``emoji`` plus a space, or '' when the terminal cannot show emoji."""
    return f"{emoji} " if UNICODE_OK else ""

def ok(message):
    """Print a green success message."""
    print(style(f"{'✔' if UNICODE_OK else '[OK]'} {message}", "32"))

def warn(message):
    """Print a red problem message."""
    print(style(f"{'✖' if UNICODE_OK else '[!]'} {message}", "31"))

def info(message):
    """Print a yellow neutral notice."""
    print(style(f"{'ℹ' if UNICODE_OK else '[i]'} {message}", "33"))

STATUS_ICONS = {
    "Pending": "📝", "Processing": "📦", "Shipped": "🚚", "Delivered": "🎉",
    "Cancelled": "❌", "Unpaid": "⏳", "Paid": "💚", "Refunded": "↩️",
}

def status_badge(status):
    """Return a colored status name with its icon."""
    return style(f"{icon(STATUS_ICONS.get(status, ''))}{status}", STATUS_STYLES.get(status, "0"))

def bar(value, maximum, width=20):
    """Return a text bar showing value/maximum, e.g. '██████░░░░'."""
    filled = round(width * value / maximum) if maximum else 0
    full, empty = ("█", "░") if UNICODE_OK else ("#", "-")
    return full * filled + empty * (width - filled)

TRACK_STEPS = [("Pending", "Placed", "📝"), ("Processing", "Processing", "📦"),
               ("Shipped", "Shipped", "🚚"), ("Delivered", "Delivered", "🎉")]

def progress_tracker(status):
    """Return a one-line delivery progress tracker for a shipping status."""
    if status == "Cancelled":
        return style(f"{icon('❌')}Cancelled - this order will not be shipped", "31")
    keys = [step[0] for step in TRACK_STEPS]
    current = keys.index(status)
    done_mark, now_mark, todo_mark = ("✔", "●", "○") if UNICODE_OK else ("[x]", "[>]", "[ ]")
    parts = []
    for position, (key, label, emoji) in enumerate(TRACK_STEPS):
        if position < current or status == "Delivered":
            parts.append(style(f"{done_mark} {icon(emoji)}{label}", "32"))
        elif position == current:
            parts.append(style(f"{now_mark} {icon(emoji)}{label}", "1;33"))
        else:
            parts.append(style(f"{todo_mark} {icon(emoji)}{label}", "90"))
    link = style(" ━━ " if UNICODE_OK else " -- ", "90")
    return link.join(parts)

#  business rules
def can_transition(current, new):
    """Return True if an order may move from shipping status ``current`` to ``new``."""
    return new in ALLOWED_TRANSITIONS.get(current, [])

def allowed_next_statuses(current):
    """Return the list of shipping statuses an order may move to next."""
    return list(ALLOWED_TRANSITIONS.get(current, []))

def calculate_order_total(items):
    """Return the total of (product, quantity, unit_price) tuples."""
    return sum(quantity * price for _, quantity, price in items)

def is_valid_email(email):
    """Return True if ``email`` looks like name@domain.tld."""
    return bool(EMAIL_PATTERN.match(email))

def is_valid_name(name):
    """Return True for 2-60 characters made of letters, spaces and . ' - only."""
    cleaned = name.strip()
    return (2 <= len(cleaned) <= 60
            and any(ch.isalpha() for ch in cleaned)
            and all(ch.isalpha() or ch in " .'-" for ch in cleaned))

def paginate(rows, page, page_size=10):
    """Return (rows_on_page, page_number, total_pages); page is clamped to a valid value."""
    total_pages = max(1, -(-len(rows) // page_size))  # ceiling division
    page = min(max(page, 1), total_pages)
    start = (page - 1) * page_size
    return rows[start:start + page_size], page, total_pages

#  formatting
def format_money(amount):
    """Format a number as Philippine pesos, e.g. 'PHP 1,250.00'."""
    return f"PHP {amount:,.2f}"

def banner(title, emoji=""):
    """Print a colored, boxed section heading."""
    text = f"{icon(emoji)}{title}"
    line = "=" * (len(title) + 6)
    print("\n" + style(f"{line}\n  {text}\n{line}", "1;36"))

def print_table(headers, rows):
    """Print rows (lists of values) as an aligned, color-highlighted text table."""
    if not rows:
        print("  (no records found)")
        return
    text_rows = [[str(cell) for cell in row] for row in rows]
    widths = [max(len(h), *(len(r[i]) for r in text_rows)) for i, h in enumerate(headers)]
    header_line = "  ".join(h.ljust(w) for h, w in zip(headers, widths))
    print(style(header_line, "1"))
    print("-" * len(header_line))
    for row in text_rows:
        cells = []
        for cell, width in zip(row, widths):
            padded = cell.ljust(width)
            if cell in STATUS_STYLES:
                padded = padded.replace(cell, style(cell, STATUS_STYLES[cell]), 1)
            cells.append(padded)
        print("  ".join(cells))


#  validated input
def read_text(prompt, required=True, max_length=100):
    """Prompt for text; keep asking while it is empty (if required) or too long."""
    while True:
        value = input(prompt).strip()
        if not value and required:
            print("  This field is required.")
        elif len(value) > max_length:
            print(f"  Please use at most {max_length} characters.")
        else:
            return value

def read_name(prompt):
    """Prompt for a person's name and validate it with is_valid_name()."""
    while True:
        value = read_text(prompt)
        if is_valid_name(value):
            return value
        print("  Names need 2-60 letters (spaces, . ' - allowed); no digits or symbols.")

def read_email(prompt):
    """Prompt for an email address; returns it lower-cased."""
    while True:
        value = read_text(prompt).lower()
        if is_valid_email(value):
            return value
        print("  Invalid email. Example: juan@example.com")

def read_int(prompt, minimum=None, maximum=None, allow_blank=False):
    """Prompt for a whole number within optional bounds. Blank returns None if allowed."""
    while True:
        raw = input(prompt).strip()
        if allow_blank and raw == "":
            return None
        try:
            number = int(raw)  # type conversion: str -> int
        except ValueError:
            print("  Please enter a whole number.")
            continue
        if minimum is not None and number < minimum:
            print(f"  Value must be at least {minimum}.")
        elif maximum is not None and number > maximum:
            print(f"  Value must be at most {maximum}.")
        else:
            return number

def read_float(prompt, minimum=0.0, maximum=1_000_000.0):
    """Prompt for a decimal number between ``minimum`` and ``maximum``."""
    while True:
        raw = input(prompt).strip().replace(",", "")
        try:
            number = float(raw)  # type conversion: str -> float
        except ValueError:
            print("  Please enter a number, e.g. 249.50.")
            continue
        if not minimum <= number <= maximum:
            print(f"  Value must be between {minimum:,.0f} and {maximum:,.0f}.")
        else:
            return number

def read_date(prompt, allow_blank=False, allow_future=True):
    """Prompt for a YYYY-MM-DD date. Returns an ISO string (None if blank allowed)."""
    while True:
        raw = input(prompt).strip()
        if allow_blank and raw == "":
            return None
        try:
            parsed = datetime.strptime(raw, "%Y-%m-%d").date()
        except ValueError:
            print("  Use a real date in the format YYYY-MM-DD, e.g. 2026-11-07.")
            continue
        if not allow_future and parsed > date.today():
            print("  The date cannot be in the future.")
            continue
        return parsed.isoformat()

def read_choice(title, options, allow_cancel=False):
    """Show a numbered list; return the chosen option (None if 0 = cancel is allowed)."""
    print(title)
    for number, option in enumerate(options, start=1):
        print(f"  {number}. {option}")
    if allow_cancel:
        print("  0. Cancel")
    index = read_int("Choice: ", minimum=0 if allow_cancel else 1, maximum=len(options))
    return None if index == 0 else options[index - 1]

def read_yes_no(prompt):
    """Ask a yes/no question until the answer is y/yes or n/no; return a bool."""
    while True:
        answer = input(f"{prompt} (y/n): ").strip().lower()
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no"):
            return False
        print("  Please answer y or n.")


# 2. DATABASE: tables and SQL operations (all parameterized)

# ORDER_DB_PATH lets tests use a throw-away database instead of the real one.
DB_PATH = Path(os.environ.get("ORDER_DB_PATH")
               or Path(__file__).resolve().parent / "database" / "orders.db")

SHIPPING_STATUSES = ["Pending", "Processing", "Shipped", "Delivered", "Cancelled"]
PAYMENT_STATUSES = ["Unpaid", "Paid", "Refunded"]

def _sql_list(values):
    """Turn a list of constants into a SQL list, e.g. ('A', 'B'). Constants only."""
    return "(" + ", ".join(f"'{v}'" for v in values) + ")"

def get_connection(db_path=DB_PATH):
    """Open (and create if needed) the SQLite database with foreign keys enabled."""
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn

def create_tables(conn):
    """Create the related tables if they do not exist yet (and upgrade old databases)."""
    conn.executescript(f"""
        CREATE TABLE IF NOT EXISTS customers (
            customer_id  INTEGER PRIMARY KEY AUTOINCREMENT,
            name         TEXT NOT NULL,
            email        TEXT NOT NULL UNIQUE,
            city         TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS orders (
            order_id        INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id     INTEGER NOT NULL,
            order_date      TEXT NOT NULL,
            shipping_status TEXT NOT NULL DEFAULT 'Pending'
                CHECK (shipping_status IN {_sql_list(SHIPPING_STATUSES)}),
            payment_status  TEXT NOT NULL DEFAULT 'Unpaid'
                CHECK (payment_status IN {_sql_list(PAYMENT_STATUSES)}),
            shipped_date    TEXT,
            delivered_date  TEXT,
            route_stage     INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (customer_id) REFERENCES customers (customer_id)
                ON DELETE RESTRICT
        );

        CREATE TABLE IF NOT EXISTS order_status_history (
            history_id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id   INTEGER NOT NULL,
            event      TEXT NOT NULL,
            changed_at TEXT NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders (order_id)
                ON DELETE CASCADE
        );

        CREATE TABLE IF NOT EXISTS order_items (
            item_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id     INTEGER NOT NULL,
            product_name TEXT NOT NULL,
            quantity     INTEGER NOT NULL CHECK (quantity > 0),
            unit_price   REAL NOT NULL CHECK (unit_price >= 0),
            FOREIGN KEY (order_id) REFERENCES orders (order_id)
                ON DELETE CASCADE
        );
    """)
    # Upgrade an older orders.db that was created before parcel locations existed.
    columns = {row["name"] for row in conn.execute("PRAGMA table_info(orders)")}
    if "route_stage" not in columns:
        conn.execute("ALTER TABLE orders ADD COLUMN route_stage INTEGER NOT NULL DEFAULT 0")
        conn.execute("UPDATE orders SET route_stage = 1 WHERE shipping_status = 'Shipped'")
        conn.execute("UPDATE orders SET route_stage = 4 WHERE shipping_status = 'Delivered'")
    conn.commit()

def _now():
    """Current local time as 'YYYY-MM-DD HH:MM' (used to stamp tracking events)."""
    return datetime.now().strftime("%Y-%m-%d %H:%M")

def _log_event(conn, order_id, event, changed_at=None):
    """Append one tracking event to an order's history (call inside a transaction)."""
    conn.execute(
        "INSERT INTO order_status_history (order_id, event, changed_at) VALUES (?, ?, ?)",
        (order_id, event, changed_at or _now()),
    )

#customers
def add_customer(conn, customer):
    """Insert a customer and return the new customer_id.

    Raises sqlite3.IntegrityError if the email already exists.
    """
    with conn:
        cur = conn.execute(
            "INSERT INTO customers (name, email, city) VALUES (?, ?, ?)",
            (customer.name, customer.email, customer.city),
        )
    return cur.lastrowid

def get_customers(conn):
    """Return all customers with how many orders each has placed."""
    return conn.execute("""
        SELECT c.customer_id, c.name, c.email, c.city,
               COUNT(o.order_id) AS order_count
        FROM customers c
        LEFT JOIN orders o ON o.customer_id = c.customer_id
        GROUP BY c.customer_id
        ORDER BY c.customer_id
    """).fetchall()

def customer_exists(conn, customer_id):
    """Return True if the customer_id exists."""
    row = conn.execute(
        "SELECT 1 FROM customers WHERE customer_id = ?", (customer_id,)
    ).fetchone()
    return row is not None

#  orders
def add_order(conn, customer_id, order_date, items, payment_status="Unpaid",
              shipping_status="Pending", shipped_date=None, delivered_date=None):
    """Insert an order and its items in one transaction; return the order_id.

    ``items`` is a list of (product_name, quantity, unit_price) tuples.
    """
    stage = {"Shipped": 1, "Delivered": 4}.get(shipping_status, 0)
    with conn:  # commits on success, rolls back on error
        cur = conn.execute(
            """INSERT INTO orders (customer_id, order_date, shipping_status,
                                   payment_status, shipped_date, delivered_date, route_stage)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (customer_id, order_date, shipping_status, payment_status,
             shipped_date, delivered_date, stage),
        )
        order_id = cur.lastrowid
        conn.executemany(
            """INSERT INTO order_items (order_id, product_name, quantity, unit_price)
               VALUES (?, ?, ?, ?)""",
            [(order_id, name, qty, price) for name, qty, price in items],
        )
        # Tracking history: what has happened to this order so far.
        placed_at = _now() if order_date == date.today().isoformat() else order_date
        _log_event(conn, order_id, "Order placed", placed_at)
        if payment_status != "Unpaid":
            _log_event(conn, order_id, f"Payment: {payment_status}", placed_at)
        if shipping_status == "Cancelled":
            _log_event(conn, order_id, "Shipping: Cancelled", placed_at)
        if shipping_status in ("Processing", "Shipped", "Delivered"):
            _log_event(conn, order_id, "Shipping: Processing", placed_at)
        if shipping_status in ("Shipped", "Delivered"):
            _log_event(conn, order_id, "Shipping: Shipped", shipped_date or placed_at)
        if shipping_status == "Delivered":
            _log_event(conn, order_id, "Shipping: Delivered", delivered_date or placed_at)
    return order_id

def get_orders(conn, order_id=None, customer_keyword=None, shipping_status=None,
               payment_status=None, date_from=None, date_to=None):
    """Return orders (with customer name, city and computed total), newest first.

    Every argument is an optional filter; all given filters must match.
    """
    clauses, params = [], []
    if order_id is not None:
        clauses.append("o.order_id = ?")
        params.append(order_id)
    if customer_keyword:
        clauses.append("c.name LIKE ?")
        params.append(f"%{customer_keyword}%")
    if shipping_status:
        clauses.append("o.shipping_status = ?")
        params.append(shipping_status)
    if payment_status:
        clauses.append("o.payment_status = ?")
        params.append(payment_status)
    if date_from:
        clauses.append("o.order_date >= ?")
        params.append(date_from)
    if date_to:
        clauses.append("o.order_date <= ?")
        params.append(date_to)
    where = ("WHERE " + " AND ".join(clauses)) if clauses else ""

    # `where` only ever contains the fixed clauses above; values stay in params.
    query = f"""
        SELECT o.order_id, c.name AS customer, c.city AS city, o.order_date,
               o.shipping_status, o.payment_status,
               COALESCE(SUM(oi.quantity * oi.unit_price), 0) AS total,
               o.shipped_date, o.delivered_date, o.route_stage,
               COALESCE(SUM(oi.quantity), 0) AS item_count
        FROM orders o
        JOIN customers c ON c.customer_id = o.customer_id
        LEFT JOIN order_items oi ON oi.order_id = o.order_id
        {where}
        GROUP BY o.order_id
        ORDER BY o.order_date DESC, o.order_id DESC
    """
    return conn.execute(query, params).fetchall()


def get_order_items(conn, order_id):
    """Return the line items of one order."""
    return conn.execute(
        """SELECT item_id, product_name, quantity, unit_price,
                  quantity * unit_price AS line_total
           FROM order_items WHERE order_id = ? ORDER BY item_id""",
        (order_id,),
    ).fetchall()


def get_status_history(conn, order_id):
    """Return an order's tracking events, oldest first."""
    return conn.execute(
        """SELECT event, changed_at FROM order_status_history
           WHERE order_id = ? ORDER BY changed_at, history_id""",
        (order_id,),
    ).fetchall()


def update_order_status(conn, order_id, shipping_status=None, payment_status=None):
    """Update shipping and/or payment status. Return False if the order is missing.

    Shipped/delivered dates and the parcel's map position are maintained
    automatically from the new status.
    """
    if conn.execute("SELECT 1 FROM orders WHERE order_id = ?", (order_id,)).fetchone() is None:
        return False
    today = date.today().isoformat()
    with conn:
        if shipping_status:
            conn.execute("UPDATE orders SET shipping_status = ? WHERE order_id = ?",
                         (shipping_status, order_id))
            _log_event(conn, order_id, f"Shipping: {shipping_status}")
            if shipping_status == "Shipped":
                conn.execute(
                    """UPDATE orders SET shipped_date = COALESCE(shipped_date, ?),
                       delivered_date = NULL, route_stage = MAX(route_stage, 1)
                       WHERE order_id = ?""", (today, order_id))
            elif shipping_status == "Delivered":
                conn.execute(
                    """UPDATE orders SET shipped_date = COALESCE(shipped_date, ?),
                       delivered_date = COALESCE(delivered_date, ?), route_stage = 4
                       WHERE order_id = ?""", (today, today, order_id))
            elif shipping_status in ("Pending", "Processing"):
                conn.execute(
                    """UPDATE orders SET shipped_date = NULL, delivered_date = NULL,
                       route_stage = 0 WHERE order_id = ?""", (order_id,))
        if payment_status:
            conn.execute("UPDATE orders SET payment_status = ? WHERE order_id = ?",
                         (payment_status, order_id))
            _log_event(conn, order_id, f"Payment: {payment_status}")

    return True


def advance_parcel(conn, order_id):
    """Move a Shipped parcel to the next stop on its route; return the new stop name.

    Returns None if the order is missing, is not Shipped, or is already out for delivery
    (the last step, Delivered, is done through the shipping status).
    """
    rows = get_orders(conn, order_id=order_id)
    if not rows:
        return None
    order = rows[0]
    stage = order_stage(order)
    if order["shipping_status"] != "Shipped" or stage is None or stage >= 3:
        return None
    new_stage = stage + 1
    title = route_stops(order["city"])[new_stage][0]
    with conn:
        conn.execute("UPDATE orders SET route_stage = ? WHERE order_id = ?",
                     (new_stage, order_id))
        _log_event(conn, order_id, f"Location: {title}")
    return title


def update_item_quantity(conn, order_id, item_id, quantity):
    """Change an item's quantity. Return False if the item is not in that order."""
    with conn:
        cur = conn.execute(
            "UPDATE order_items SET quantity = ? WHERE item_id = ? AND order_id = ?",
            (quantity, item_id, order_id),
        )
    return cur.rowcount > 0


def delete_order(conn, order_id):
    """Delete an order (its items are removed by ON DELETE CASCADE)."""
    with conn:
        cur = conn.execute("DELETE FROM orders WHERE order_id = ?", (order_id,))
    return cur.rowcount > 0


def get_quick_stats(conn):
    """Return headline counts shown on the main-menu dashboard."""
    return conn.execute("""
        SELECT (SELECT COUNT(*) FROM customers) AS customers,
               COUNT(*) AS orders,
               COALESCE(SUM(shipping_status IN ('Pending', 'Processing')), 0) AS to_ship,
               COALESCE(SUM(shipping_status = 'Shipped'), 0) AS in_transit,
               COALESCE(SUM(payment_status = 'Unpaid'
                            AND shipping_status != 'Cancelled'), 0) AS unpaid
        FROM orders
    """).fetchone()

# 3. DELIVERY MAP: where is the parcel right now?

STORE_NAME = os.environ.get("STORE_NAME", "").strip() or "Store Warehouse"
STORE_PLACE = os.environ.get("STORE_CITY", "").strip()  # warehouse city for map links


def route_stops(city):
    """Return the delivery route as [(stop name, place used for map links), ...].

    Stage numbers: 0 warehouse, 1 sorting hub, 2 local hub, 3 out for delivery, 4 delivered.
    """
    origin = STORE_PLACE or city
    return [
        (STORE_NAME, origin),
        ("Sorting Hub", origin),
        (f"{city} Delivery Hub", city),
        (f"Out for delivery to {city}", city),
        (f"Delivered - {city}", city),
    ]


def order_stage(order):
    """Return the parcel's stop number (0-4) for an order row, or None if cancelled."""
    status = order["shipping_status"]
    if status == "Cancelled":
        return None
    if status == "Delivered":
        return 4
    if status == "Shipped":
        return min(max(order["route_stage"], 1), 3)
    return 0


def where_is_order(order):
    """Describe where an order is: stage, a friendly sentence, place and message tone."""
    stage = order_stage(order)
    city = order["city"]
    if stage is None:
        return {"stage": None, "place": "-", "map_place": None, "tone": "red",
                "headline": "This order has been cancelled and will not be delivered."}
    title, map_place = route_stops(city)[stage]
    status = order["shipping_status"]
    if status == "Pending":
        text, tone = "We received your order and are getting it ready.", "amber"
    elif status == "Processing":
        text, tone = f"Your order is being packed at {title}.", "amber"
    elif status == "Delivered":
        text, tone = f"Your order has ARRIVED - delivered to {city}. Enjoy!", "green"
    elif stage == 1:
        text, tone = "Your parcel has shipped and is now at the Sorting Hub.", "blue"
    elif stage == 2:
        text, tone = f"Your parcel arrived at the {title}.", "blue"
    else:
        text, tone = "Your order is OUT FOR DELIVERY - it will reach you very soon!", "blue"
    return {"stage": stage, "place": title, "map_place": map_place,
            "tone": tone, "headline": text}


def map_url(place):
    """Return a Google Maps link that searches for ``place``."""
    return "https://www.google.com/maps/search/?api=1&query=" + urllib.parse.quote(place)


def route_map_lines(order, fancy=True, color=True):
    """Return the delivery route as text lines with a marker on the parcel's stop."""
    stage = order_stage(order)
    if stage is None:
        return ["  Cancelled - this order will not be delivered."]
    done, now, todo = ("✔", "●", "○") if fancy else ("[x]", "[>]", "[ ]")
    pipe = "│" if fancy else "|"
    lines = []
    stops = route_stops(order["city"])
    for index, (title, _place) in enumerate(stops):
        if index < stage or stage == 4:
            mark, code, tag = done, "32", ""
        elif index == stage:
            mark, code, tag = now, "1;33", "   <-- YOUR PARCEL IS HERE"
        else:
            mark, code, tag = todo, "90", ""
        if stage == 4 and index == 4:
            tag = "   <-- DELIVERED"
        text = f"  {mark} {title}{tag}"
        lines.append(style(text, code) if color else text)
        if index < len(stops) - 1:
            lines.append(style(f"  {pipe}", "90") if color else f"  {pipe}")
    return lines


def print_route_map(order):
    """Print the delivery map, journey bar and a clickable map link."""
    where = where_is_order(order)
    print(style(f"\n  {icon('🗺️')}DELIVERY MAP", "1;36"))
    for line in route_map_lines(order, fancy=UNICODE_OK):
        print(line)
    if where["stage"] is not None:
        percent = where["stage"] * 25
        print(f"\n  Journey: {bar(where['stage'], 4, 24)} {percent}%")
    print(f"  {icon('📍')}{where['headline']}")
    if where["map_place"]:
        print(f"  Map link: {map_url(where['map_place'])}")


def _route_rows_html(order):
    """Return the delivery route as HTML table rows (used by the browser map page)."""
    stage = order_stage(order)
    if stage is None:
        return ('<tr><td style="color:#c0392b;padding:6px 0">'
                'Cancelled - this order will not be delivered.</td></tr>')
    rows = []
    stops = route_stops(order["city"])
    for index, (title, _place) in enumerate(stops):
        badge = ""
        if index < stage or stage == 4:
            mark, color, weight = "&#10004;", "#1e8449", "normal"
        elif index == stage:
            mark, color, weight = "&#9679;", "#1f5fa8", "bold"
            badge = ('<span style="background:#1f5fa8;color:#ffffff;border-radius:10px;'
                     'padding:2px 8px;font-size:12px;margin-left:8px">YOUR PARCEL IS HERE</span>')
        else:
            mark, color, weight = "&#9675;", "#999999", "normal"
        if stage == 4 and index == 4:
            badge = ('<span style="background:#1e8449;color:#ffffff;border-radius:10px;'
                     'padding:2px 8px;font-size:12px;margin-left:8px">DELIVERED</span>')
        rows.append(
            f'<tr><td style="width:30px;text-align:center;color:{color};font-size:18px">{mark}</td>'
            f'<td style="color:{color};font-weight:{weight};font-size:15px;padding:2px 0">'
            f'{html.escape(title)}{badge}</td></tr>')
        if index < len(stops) - 1:
            rows.append('<tr><td style="text-align:center;color:#cccccc;line-height:12px">'
                        '&#9474;</td><td></td></tr>')
    return "".join(rows)


MAP_PAGE_TEMPLATE = """<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>@@TITLE@@</title>
<style>
 body{font-family:Segoe UI,Arial,sans-serif;background:#f4f6f8;margin:0;padding:20px;color:#222}
 .card{max-width:760px;margin:0 auto;background:#fff;border-radius:10px;padding:22px;
       box-shadow:0 2px 8px rgba(0,0,0,.1)}
 h1{margin:0 0 4px;font-size:22px} .sub{color:#666;margin-bottom:14px}
 .banner{padding:12px 14px;border-radius:8px;font-weight:600;margin:12px 0}
 iframe{width:100%;height:340px;border:0;border-radius:8px;margin:12px 0}
 table{border-collapse:collapse} a{color:#1f5fa8}
</style></head><body><div class="card">
<h1>@@TITLE@@</h1><div class="sub">@@SUB@@</div>
<div class="banner" style="background:@@BG@@;color:@@FG@@">@@HEADLINE@@</div>
<iframe src="@@EMBED@@" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
<div><a href="@@LINK@@" target="_blank">Open in Google Maps</a></div>
<h3>Delivery route</h3><table>@@ROUTE@@</table>
<h3>Items</h3><table cellpadding="4">@@ITEMS@@</table>
<p><b>Total: @@TOTAL@@</b></p>
<p style="color:#888;font-size:12px">The map needs an internet connection.</p>
</div></body></html>
"""

TONE_COLORS = {
    "green": ("#e6f6ec", "#1e8449"),
    "blue": ("#e8f1fb", "#1f5fa8"),
    "amber": ("#fff6e0", "#9a6700"),
    "red": ("#fdecea", "#c0392b"),
}


def write_map_page(conn, order_id):
    """Write an HTML page with a live map of the parcel's place; return its path."""
    snap = _order_snapshot(conn, order_id)
    if snap is None:
        return None
    order, where = snap["order"], snap["where"]
    place = where["map_place"] or order["city"]
    bg, fg = TONE_COLORS[where["tone"]]
    items = "".join(
        f"<tr><td>{html.escape(i['product_name'])}</td><td>x{i['quantity']}</td>"
        f"<td align='right'>{format_money(i['line_total'])}</td></tr>" for i in snap["items"])
    values = {
        "@@TITLE@@": html.escape(f"Order #{order_id} - delivery map"),
        "@@SUB@@": html.escape(f"{order['customer']} | placed {order['order_date']}"),
        "@@BG@@": bg, "@@FG@@": fg,
        "@@HEADLINE@@": html.escape(where["headline"]),
        "@@EMBED@@": html.escape("https://maps.google.com/maps?q="
                                 + urllib.parse.quote(place) + "&z=13&output=embed", quote=True),
        "@@LINK@@": html.escape(map_url(place), quote=True),
        "@@ROUTE@@": _route_rows_html(order),
        "@@ITEMS@@": items,
        "@@TOTAL@@": format_money(order["total"]),
    }
    page = MAP_PAGE_TEMPLATE
    for token, value in values.items():
        page = page.replace(token, value)
    folder = DB_PATH.parent / "order_maps"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"order_{order_id}_map.html"
    path.write_text(page, encoding="utf-8")
    return path

# 4. ORDER SNAPSHOT (everything about one order, used by the map page)

def _order_snapshot(conn, order_id):
    """Gather the order, its items, its history and where it is right now."""
    rows = get_orders(conn, order_id=order_id)
    if not rows:
        return None
    order = rows[0]
    return {"order": order, "items": get_order_items(conn, order_id),
            "history": get_status_history(conn, order_id), "where": where_is_order(order)}


# 5. SHIPPING & PAYMENT BOARD

# One row per order with its computed total (used by several measures).
ORDER_TOTALS = """
    SELECT o.order_id, o.order_date, o.shipping_status, o.payment_status,
           SUM(oi.quantity * oi.unit_price) AS total
    FROM orders o
    JOIN order_items oi ON oi.order_id = o.order_id
    GROUP BY o.order_id
"""

def shipping_summary(conn):
    """Orders and value per shipping status (all statuses, in workflow order)."""
    found = {row["shipping_status"]: row for row in conn.execute(f"""
        SELECT shipping_status, COUNT(*) AS orders, SUM(total) AS amount
        FROM ({ORDER_TOTALS}) AS t GROUP BY shipping_status""")}
    return [(s, found[s]["orders"] if s in found else 0,
             found[s]["amount"] if s in found else 0.0) for s in SHIPPING_STATUSES]

def payment_summary(conn):
    """Orders and value per payment status (cancelled orders excluded, except refunds)."""
    found = {row["payment_status"]: row for row in conn.execute(f"""
        SELECT payment_status, COUNT(*) AS orders, SUM(total) AS amount
        FROM ({ORDER_TOTALS}) AS t
        WHERE shipping_status != 'Cancelled' OR payment_status = 'Refunded'
        GROUP BY payment_status""")}
    return [(s, found[s]["orders"] if s in found else 0,
             found[s]["amount"] if s in found else 0.0) for s in PAYMENT_STATUSES]

def customer_totals(conn):
    """Per-customer orders, items, order value, amount paid and amount unpaid."""
    return conn.execute("""
        SELECT c.name,
               COUNT(t.order_id) AS orders,
               SUM(t.items) AS items,
               SUM(CASE WHEN t.shipping_status != 'Cancelled' THEN t.total ELSE 0 END) AS total,
               SUM(CASE WHEN t.payment_status = 'Paid' THEN t.total ELSE 0 END) AS paid,
               SUM(CASE WHEN t.payment_status = 'Unpaid'
                         AND t.shipping_status != 'Cancelled' THEN t.total ELSE 0 END) AS unpaid
        FROM customers c
        JOIN (SELECT o.order_id, o.customer_id, o.shipping_status, o.payment_status,
                     SUM(oi.quantity) AS items, SUM(oi.quantity * oi.unit_price) AS total
              FROM orders o JOIN order_items oi ON oi.order_id = o.order_id
              GROUP BY o.order_id) AS t ON t.customer_id = c.customer_id
        GROUP BY c.customer_id
        ORDER BY total DESC, c.name
    """).fetchall()

def print_board(conn):
    """Colorful board: shipping statuses, payment totals, and per-customer totals."""
    banner("Shipping & Payment Board", "📊")
    if conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0] == 0:
        print("No orders stored yet. Register a customer and place an order first.")
        return

    print(style("\nShipping statuses", "1"))
    shipping = shipping_summary(conn)
    most = max(n for _, n, _ in shipping)
    for status, orders, amount in shipping:
        label = f"{icon(STATUS_ICONS[status])}{status}"
        pad = " " * (14 - len(status) - (2 if UNICODE_OK else 0))
        line = f"  {label}{pad}{bar(orders, most)}  {orders:>3} order{'s' if orders != 1 else ' '}  {format_money(amount):>16}"
        print(style(line, STATUS_STYLES[status]))

    print(style("\nPayment totals (cancelled orders excluded, except refunds)", "1"))
    payments = {s: (n, amt) for s, n, amt in payment_summary(conn)}
    for status in PAYMENT_STATUSES:
        orders, amount = payments[status]
        label = f"{icon(STATUS_ICONS[status])}{status}"
        pad = " " * (14 - len(status) - (2 if UNICODE_OK else 0))
        line = f"  {label}{pad}{format_money(amount):>16}   ({orders} order{'s' if orders != 1 else ''})"
        print(style(line, STATUS_STYLES[status]))
    paid, unpaid = payments["Paid"][1], payments["Unpaid"][1]
    billable = paid + unpaid
    rate = (paid / billable * 100) if billable else 0.0
    print(style(f"  {icon('🎯')}Collection rate: {rate:.1f}% of billable value "
                f"({format_money(paid)} of {format_money(billable)})", "1;35"))

    print(style("\nCustomer totals (highest order value first)", "1"))
    print_table(["Customer", "Orders", "Items", "Order value", "Paid", "Unpaid"],
                [[r["name"], r["orders"], r["items"], format_money(r["total"]),
                  format_money(r["paid"]), format_money(r["unpaid"])]
                 for r in customer_totals(conn)])


# 6. MENU FLOWS AND PROGRAM START

def welcome_screen():
    """Show a colorful welcome screen with a short terminal fireworks animation."""
    if _USE_COLOR:
        os.system("cls" if os.name == "nt" else "clear")

    width = 66
    line = "═" * width if UNICODE_OK else "=" * width
    print("\n" + style("╔" + line + "╗" if UNICODE_OK else line, "1;35"))
    print(style("                 ✨ WELCOME TO ✨", "1;33"))
    print(style("          ONLINE ORDER FULFILLMENT TRACKER", "1;36"))
    print(style("       Manage your customers, orders & deliveries", "1;35"))
    print(style("╚" + line + "╝" if UNICODE_OK else line, "1;35"))
    print(style("\n                 LET'S GET STARTED!", "1;32"))

    # Fireworks use ANSI colors when supported; plain symbols otherwise.
    fireworks = ["✦", "✧", "＊", "✺", "·", "*", "+"]
    colors = ["31", "32", "33", "34", "35", "36", "1;33"]
    for _frame in range(5):
        pieces = []
        for _ in range(7):
            symbol = random.choice(fireworks) if UNICODE_OK else random.choice(["*", "+", "."])
            pieces.append(style(symbol, random.choice(colors)))
        print("       " + "   ".join(pieces))
        time.sleep(0.22)
    print(style("\n       Hello! We're happy to have you here.", "1;36"))
    print(style("       Your order records are ready to be managed.", "1;32"))
    input(style("\n       Press ENTER to continue to the main menu...", "1;33"))

def show_menu(conn):
    """Display a polished main menu and live order dashboard."""
    stats = get_quick_stats(conn)
    width = 72
    border = "═" * width if UNICODE_OK else "=" * width
    thin = "─" * width if UNICODE_OK else "-" * width
    print("\n" + style("╔" + border + "╗" if UNICODE_OK else border, "1;35"))
    print(style(f"   {icon('🛒')}ONLINE ORDER FULFILLMENT TRACKER {icon('🚚')}", "1;36"))
    print(style("       Manage customers • Orders • Shipping • Payments", "90"))
    print(style("╚" + border + "╝" if UNICODE_OK else border, "1;35"))
    print(style("  LIVE DASHBOARD", "1;36"))
    print(f"  {icon('👥')}Customers: {style(stats['customers'], '1;36')}   "
          f"{icon('📦')}Orders: {style(stats['orders'], '1;36')}   "
          f"{icon('🕒')}To ship: {style(stats['to_ship'], '1;33')}   "
          f"{icon('🚚')}In transit: {style(stats['in_transit'], '1;34')}   "
          f"{icon('💳')}Unpaid: {style(stats['unpaid'], '1;31')}")
    print(style(thin, "35"))
    print(style("  MAIN MENU", "1;36"))
    for key, emoji, label, _ in MENU:
        if key == "0":
            print(style(thin, "35"))
            print(f"  {style(' 0 ', '1;31')}  {icon(emoji)}{style(label, '1;31')}  "
                  f"{style('Thank you for using our system!', '90')}")
        else:
            print(f"  {style(f' {key:>2} ', '1;35')}  {icon(emoji)}{label}")
    print(style(thin, "35"))

def farewell():
    """Show a friendly thank-you screen when the user chooses Exit."""
    width = 58
    line = "═" * width if UNICODE_OK else "=" * width
    print("\n" + style("╔" + line + "╗" if UNICODE_OK else line, "1;36"))
    print(style("        THANK YOU FOR USING OUR TRACKER!", "1;32"))
    print(style("          Your orders are safe with us.", "1;36"))
    print(style("       We appreciate your time and trust.", "1;36"))
    print(style("              Have a great day!", "1;33"))
    print(style("╚" + line + "╝" if UNICODE_OK else line, "1;36"))
    print(f"  {icon('👋')}Goodbye! See you again soon.\n")

def show_orders(rows):
    """Print a list of order rows as a table."""
    print_table(
        ["ID", "Customer", "Order date", "Items", "Shipping", "Payment", "Total"],
        [[r["order_id"], r["customer"], r["order_date"], r["item_count"], r["shipping_status"],
          r["payment_status"], format_money(r["total"])] for r in rows],
    )

def add_customer_flow(conn):
    """Register a new customer after validating every field."""
    banner("Register Customer", "🧑")
    name = read_name("Full name: ")
    email = read_email("Email: ")
    city = read_text("City: ", max_length=60)
    try:
        customer_id = add_customer(conn, Customer(name=name, email=email, city=city))
        ok(f"Customer saved with ID {customer_id}.")
    except sqlite3.IntegrityError:
        warn("A customer with that email already exists. Nothing was saved.")

def view_customers_flow(conn):
    """List all customers."""
    banner("Customers", "👥")
    rows = get_customers(conn)
    print_table(
        ["ID", "Name", "Email", "City", "Orders"],
        [[r["customer_id"], r["name"], r["email"], r["city"], r["order_count"]]
         for r in rows],
    )

def add_order_flow(conn):
    """Create an order with one or more items, reviewed before saving."""
    banner("Place Order", "🛍️")
    if not get_customers(conn):
        info("No registered customers yet. Register a customer first (option 1).")
        return
    view_customers_flow(conn)
    customer_id = read_int("\nCustomer ID (blank to cancel): ", minimum=1, allow_blank=True)
    if customer_id is None:
        info("Cancelled.")
        return
    if not customer_exists(conn, customer_id):
        warn(f"No customer with ID {customer_id}.")
        return

    order_date = read_date("Order date (YYYY-MM-DD, blank = today): ",
                           allow_blank=True, allow_future=False)
    order_date = order_date or date.today().isoformat()

    items = []
    while True:
        product = read_text("Product name (blank to finish): ", required=False)
        if not product:
            if items:
                break
            print("  An order needs at least one item.")
            continue
        quantity = read_int("  Quantity: ", minimum=1, maximum=1000)
        price = read_float("  Unit price (PHP): ", minimum=0)
        items.append((product, quantity, price))
        print(f"  Added: {quantity} x {product} = {format_money(quantity * price)}")

    payment = read_choice("Payment status:", PAYMENT_STATUSES)

    print("\nOrder review")
    print_table(["Product", "Qty", "Unit price", "Line total"],
                [[n, q, format_money(p), format_money(q * p)] for n, q, p in items])
    print(f"Date: {order_date} | Items: {sum(q for _, q, _ in items)} | "
          f"Total: {format_money(calculate_order_total(items))}")
    if not read_yes_no("Save this order?"):
        info("Order discarded.")
        return
    order_id = add_order(conn, customer_id, order_date, items, payment_status=payment)
    ok(f"Order #{order_id} saved with status Pending.")

def view_orders_flow(conn):
    """List all orders, ten per page, with next/previous navigation."""
    banner("All Orders", "📋")
    rows = get_orders(conn)
    if not rows:
        print("  (no orders found) - place an order to get started.")
        return
    page = 1
    while True:
        chunk, page, total_pages = paginate(rows, page)
        show_orders(chunk)
        print(f"\nPage {page}/{total_pages} - {len(rows)} orders in total")
        if total_pages == 1:
            break
        nav = input("[N]ext  [P]revious  [Q]uit: ").strip().lower()
        if nav in ("n", "next"):
            page += 1
        elif nav in ("p", "previous"):
            page -= 1
        elif nav in ("q", "quit", ""):
            break
        else:
            print("  Type N, P or Q.")

def order_details_flow(conn):
    """Show one order with its line items."""
    banner("Order Details", "🔎")
    order_id = read_int("Order ID: ", minimum=1)
    rows = get_orders(conn, order_id=order_id)
    if not rows:
        warn(f"No order with ID {order_id}.")
        return
    order = rows[0]
    print(f"Order #{order['order_id']} | {order['customer']} | {order['order_date']}")
    print(f"Shipping: {order['shipping_status']} | Payment: {order['payment_status']}")
    print(f"Shipped: {order['shipped_date'] or '-'} | Delivered: {order['delivered_date'] or '-'}")
    print_table(
        ["Item ID", "Product", "Qty", "Unit price", "Line total"],
        [[i["item_id"], i["product_name"], i["quantity"],
          format_money(i["unit_price"]), format_money(i["line_total"])]
         for i in get_order_items(conn, order_id)],
    )
    print(f"Order total: {format_money(order['total'])}")

def track_order_flow(conn):
    """Show an order's progress, delivery map, items, payment total and history."""
    banner("Track Order", "🚚")
    order_id = read_int("Order ID to track: ", minimum=1)
    rows = get_orders(conn, order_id=order_id)
    if not rows:
        warn(f"No order with ID {order_id}.")
        return
    order = rows[0]
    print(f"\n  Order #{order['order_id']}  -  {order['customer']} ({order['city']})")
    print(f"  Placed on {order['order_date']}  |  {order['item_count']} item(s)\n")
    print("  " + progress_tracker(order["shipping_status"]))

    print_route_map(order)

    print()
    print_table(
        ["Product", "Qty", "Unit price", "Line total"],
        [[i["product_name"], i["quantity"], format_money(i["unit_price"]),
          format_money(i["line_total"])] for i in get_order_items(conn, order_id)],
    )
    print(f"\n  {icon('💰')}Payment total: {style(format_money(order['total']), '1;32')}"
          f"   Payment status: {status_badge(order['payment_status'])}")

    print(style("\n  Tracking history", "1"))
    history = get_status_history(conn, order_id)
    if not history:
        print("  (no tracking history was recorded for this older order)")
    for entry in history:
        print(f"  {style(entry['changed_at'], '90')}  {entry['event']}")

    if read_yes_no("\nOpen the live map in your web browser?"):
        path = write_map_page(conn, order_id)
        if path is not None:
            info(f"Map page saved: {path}")
            try:
                webbrowser.open(path.as_uri())
            except webbrowser.Error:
                info("Could not open the browser automatically. Open that file by hand.")

def board_flow(conn):
    """Show the shipping and payment board."""
    print_board(conn)

def search_once(conn):
    """Run one search; return False if the user cancelled."""
    mode = read_choice("Search by:", [
        "Order ID", "Customer name (keyword)", "Shipping status",
        "Payment status", "Order date range"], allow_cancel=True)
    if mode is None:
        return False
    if mode == "Order ID":
        rows = get_orders(conn, order_id=read_int("Order ID: ", minimum=1))
    elif mode.startswith("Customer"):
        rows = get_orders(conn, customer_keyword=read_text("Name contains: "))
    elif mode == "Shipping status":
        rows = get_orders(conn, shipping_status=read_choice("Status:", SHIPPING_STATUSES))
    elif mode == "Payment status":
        rows = get_orders(conn, payment_status=read_choice("Status:", PAYMENT_STATUSES))
    else:
        start = read_date("From (YYYY-MM-DD): ")
        end = read_date("To   (YYYY-MM-DD): ")
        if start > end:
            print("The start date must not be after the end date.")
            return True
        rows = get_orders(conn, date_from=start, date_to=end)
    print(f"\n{len(rows)} order(s) found.")
    show_orders(rows)
    if rows:
        print(f"Combined value of matches: {format_money(sum(r['total'] for r in rows))}")
    return True

def search_orders_flow(conn):
    """Search repeatedly until the user is done."""
    banner("Search Orders", "🔍")
    while search_once(conn):
        if not read_yes_no("\nSearch again?"):
            break

def update_order_flow(conn):
    """Update shipping status, payment status, parcel location or an item quantity."""
    banner("Update Order", "✏️")
    order_id = read_int("Order ID to update: ", minimum=1)
    rows = get_orders(conn, order_id=order_id)
    if not rows:
        warn(f"No order with ID {order_id}. Nothing was changed.")
        return
    order = rows[0]
    show_orders(rows)

    field = read_choice("\nWhat do you want to update?",
                        ["Shipping status", "Payment status", "Parcel location (map)",
                         "Item quantity"], allow_cancel=True)
    if field is None:
        info("Update cancelled.")
        return

    if field == "Shipping status":
        options = allowed_next_statuses(order["shipping_status"])
        if not options:
            info(f"Orders that are {order['shipping_status']} are final; "
                 "their shipping status cannot change.")
            return
        status = read_choice(f"Currently {order['shipping_status']}. Move to:",
                             options, allow_cancel=True)
        if status is None:
            info("Update cancelled.")
            return
        update_order_status(conn, order_id, shipping_status=status)
        ok("Order updated.")
        print_route_map(get_orders(conn, order_id=order_id)[0])
        return
    elif field == "Payment status":
        status = read_choice("New payment status:", PAYMENT_STATUSES, allow_cancel=True)
        if status is None:
            info("Update cancelled.")
            return
        update_order_status(conn, order_id, payment_status=status)
    elif field == "Parcel location (map)":
        if order["shipping_status"] != "Shipped":
            info("The parcel location can be updated while the order is Shipped.")
            return
        stage = order_stage(order)
        if stage >= 3:
            info("The parcel is already out for delivery. "
                 "Set the shipping status to Delivered when it arrives.")
            return
        print_route_map(order)
        next_title = route_stops(order["city"])[stage + 1][0]
        if not read_yes_no(f"\nMove the parcel to '{next_title}'?"):
            info("Update cancelled.")
            return
        title = advance_parcel(conn, order_id)
        ok(f"Parcel is now at: {title}.")
        print_route_map(get_orders(conn, order_id=order_id)[0])
        return
    else:
        if order["shipping_status"] not in EDITABLE_STATUSES:
            info("Items can only be changed while an order is Pending or Processing.")
            return
        items = get_order_items(conn, order_id)
        print_table(["Item ID", "Product", "Qty"],
                    [[i["item_id"], i["product_name"], i["quantity"]] for i in items])
        item_id = read_int("Item ID: ", minimum=1)
        quantity = read_int("New quantity: ", minimum=1, maximum=1000)
        if not update_item_quantity(conn, order_id, item_id, quantity):
            warn(f"Item {item_id} is not part of order #{order_id}. Nothing was changed.")
            return
    ok("Order updated.")

def delete_order_flow(conn):
    """Delete an order after the user confirms."""
    banner("Delete Order", "🗑️")
    order_id = read_int("Order ID to delete: ", minimum=1)
    rows = get_orders(conn, order_id=order_id)
    if not rows:
        warn(f"No order with ID {order_id}. Nothing was deleted.")
        return
    show_orders(rows)
    if read_yes_no("Delete this order and all its items permanently?"):
        delete_order(conn, order_id)
        ok("Order deleted.")
    else:
        info("Deletion cancelled.")


MENU = [
    ("1", "🧑", "Register customer", add_customer_flow),
    ("2", "👥", "View customers", view_customers_flow),
    ("3", "🛍️", "Place order", add_order_flow),
    ("4", "📋", "View all orders", view_orders_flow),
    ("5", "🔎", "View order details (items)", order_details_flow),
    ("6", "🚚", "Track an order (with delivery map)", track_order_flow),
    ("7", "🔍", "Search orders", search_orders_flow),
    ("8", "✏️", "Update order (status / parcel location)", update_order_flow),
    ("9", "🗑️", "Delete order", delete_order_flow),
    ("10", "📊", "Shipping & payment board", board_flow),
    ("0", "👋", "Exit", None),
]
ACTIONS = {key: func for key, _, _, func in MENU if func}

def main():
    """Run the menu loop until the user exits."""
    conn = get_connection()
    create_tables(conn)
    try:
        welcome_screen()
        while True:
            show_menu(conn)
            choice = input(style("\n  Select an option (0-10): ", "1;36")).strip()
            if choice == "0":
                farewell()
                break
            action = ACTIONS.get(choice)
            if action is None:
                warn("Invalid choice. Please enter a number from 0 to 10.")
                continue
            try:
                action(conn)
            except sqlite3.Error as error:
                warn(f"Database error: {error}. Your data was not changed.")
    except (KeyboardInterrupt, EOFError):
        print("\n")
        farewell()
    finally:
        conn.close()

if __name__ == "__main__":
    main()
