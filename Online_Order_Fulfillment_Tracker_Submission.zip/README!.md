# Online Order Fulfillment Tracker

DSA 214 – Final Laboratory Activity – Scenario 14

A command-line order fulfillment tracker built with Python and SQLite. It manages customers, orders, order items, shipping/payment statuses, delivery progress, analytics, and charts.

## Files

- `main.py` – complete command-line application.
- `order.db` – SQLite database used directly by the application.
- `requirements.txt` – Matplotlib dependency for chart generation.
- `charts/` – generated chart images.
- `tests/test_cases.md` – manual test checklist.

## Requirements

- Python 3.9 or newer
- Matplotlib (for charts only)

Install the chart dependency:

```bash
python -m pip install -r requirements.txt
```

## Run

Keep `main.py` and `orders (10).db` in the same folder, then run:

```bash
python main.py
```

The program connects directly to the included `orders (10).db`. It does not create a second database. Data remains saved after the program closes.

Optional: set `ORDER_DB_PATH` to use a different database file. For example, on Windows Command Prompt:

```bat
set ORDER_DB_PATH=C:\path\to\orders (10).db
python main.py
```

## Main menu features

1. Register customer
2. View customers
3. Place order with one or more items
4. View all orders
5. View order details
6. Track order and delivery map
7. Search orders by ID, customer, shipping/payment status, or date range
8. Update shipping status, payment status, parcel location, or item quantity
9. Delete an order after confirmation
10. Shipping/payment dashboard and analytical measures
11. Generate two charts and display analytical measures
0. Exit

## Database design

- `customers.customer_id` is the primary key.
- `orders.order_id` is the primary key; `orders.customer_id` references `customers.customer_id`.
- `order_items.item_id` is the primary key; `order_items.order_id` references `orders.order_id`.
- `order_status_history.history_id` is the primary key; `order_status_history.order_id` references `orders.order_id`.

Foreign-key enforcement is enabled on every SQLite connection. SQL statements use parameters for user-provided values.

## Analysis and charts

The application reports total orders, delivered orders, delivery rate, non-cancelled order value, average order value, shipping-status counts/value, payment totals, and customer totals.

Menu option 11 creates:
- `charts/orders_by_shipping_status.png`
- `charts/order_value_by_payment_status.png`

Charts are based on records in the connected SQLite database. If the database has no records yet, the charts will show empty/zero data until orders are entered.

## Data safety

Make a backup copy of `orders (10).db` before making major changes. Do not share real customer names, email addresses, or other personal data in public screenshots or repositories. Use clearly labeled simulated data for classroom demonstrations.
